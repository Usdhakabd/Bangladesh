import '@/ai/flows/generate-disclaimer.ts';
import '@/ai/flows/analyze-screenshot.ts';